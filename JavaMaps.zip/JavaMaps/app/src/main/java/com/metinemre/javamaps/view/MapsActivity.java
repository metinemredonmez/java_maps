package com.metinemre.javamaps.view;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.snackbar.Snackbar;
import com.metinemre.javamaps.R;
import com.metinemre.javamaps.databinding.ActivityMapsBinding;
import com.metinemre.javamaps.model.Place;
import com.metinemre.javamaps.roomdb.PlaceDAO;
import com.metinemre.javamaps.roomdb.PlaceDatabase;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.core.Scheduler;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, GoogleMap.OnMapLongClickListener{

    private GoogleMap mMap;
    private ActivityMapsBinding binding;
    ActivityResultLauncher<String> permissionLauncher;
    LocationManager locationManager;
    LocationListener locationListener;
    SharedPreferences sharedPreferences;
    boolean info;
    PlaceDatabase db;
    PlaceDAO placeDAO;
    Double  selectedLatitude;
    Double selectedLongitude;
    private CompositeDisposable compositeDisposable =  new CompositeDisposable(); // different threadign process

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        registerLauncher();
        sharedPreferences = MapsActivity.this.getSharedPreferences("com.metinemre.javamaps;", MODE_PRIVATE);
        info = false;


        db = Room.databaseBuilder(getApplicationContext(),PlaceDatabase.class,"Places").build();
                //.allowMainThreadQueries()  // !

        placeDAO =  db.placeDAO();

        selectedLatitude = 0.0;
        selectedLongitude = 0.0;

    }



    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setOnMapLongClickListener(this);

        binding.saveButton.setEnabled(false);



        // casting
         locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);   // Full Services
         locationListener =  new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {

                 info = sharedPreferences.getBoolean("info",false);

                if (!info == false) {
                    LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 15));
                    sharedPreferences.edit().putBoolean("info",true).apply();
                }
            }
            // location change permission

        };

       // locationManager.requestLocationUpdates(locationManager.GBS_PROVIDER,0,0,locationListener);
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            //request permisssion
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.ACCESS_FINE_LOCATION)) {
                Snackbar.make(binding.getRoot(),"permission needed for maps",Snackbar.LENGTH_INDEFINITE).setAction("Give Permission", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // tıklanınca kapanan  request permission
                        permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION);
                    }
                }).show();
            }else {
                // request permisson
                permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION);


            }
        }else {
            permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION);

            //Son Konum
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
            Location lastLocation =  locationManager.getLastKnownLocation(locationManager.GPS_PROVIDER);

            if (lastLocation != null) {
                LatLng lasUserLocation =  new LatLng(lastLocation.getLatitude(),lastLocation.getLongitude());
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(lasUserLocation,15));
            }

            mMap.setMyLocationEnabled(true);
        }


        //latitude & longitude
       /* LatLng eiffel =  new LatLng(41.028550537499655, 28.997066404354424);
        mMap.addMarker(new MarkerOptions().position(eiffel).title("Eiiffel tOWER"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(eiffel,12));*/


    }
    // permissionLauncher
    private void registerLauncher() {
        permissionLauncher =
                registerForActivityResult(new ActivityResultContracts.RequestPermission(), new ActivityResultCallback<Boolean>() {
                    @Override
                    public void onActivityResult(Boolean result) {
                        if(result) {
                            //permission granted // son konum !!
                            if (ContextCompat.checkSelfPermission(MapsActivity.this,Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
                                Location lastLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                                if (lastLocation != null) {
                                    LatLng lastUserLocation = new LatLng(lastLocation.getLatitude(), lastLocation.getLongitude());
                                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(lastUserLocation, 15));
                                }
                            }

                        } else {
                            //permission denied
                            Toast.makeText(MapsActivity.this,"Permisson needed!",Toast.LENGTH_LONG).show();
                        }
                    }

                });
    }

    @Override
    public void onMapLongClick(LatLng latLng) {
        mMap.clear();
        mMap.addMarker(new MarkerOptions().position(latLng).title("Location Choose"));

        selectedLatitude = latLng.latitude;
        selectedLongitude = latLng.longitude;

        binding.saveButton.setEnabled(true);

    }


    // entities database func
    public void save(View view) {

        Place place = new Place(binding.placeNameText.getText().toString(), selectedLatitude,selectedLongitude);

        // threading  -> Main (UI) , Default (CPU Intensive) , IO (network , database)
        // placeDAO.insert(place).subscribeOn(Schedulers.io()).subscribe();

        // disposable

        compositeDisposable.add(placeDAO.insert(place)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(MapsActivity.this::handleResponse)

        );

    }


    private void handleResponse() {
        Intent intent = new Intent(MapsActivity.this,MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }


    public void delete(View view) {
      /* compositeDisposable.add(placeDAO.delete()
       .subscribeOn(Schedulers.io())
       .observeOn(AndroidSchedulers.mainThread()).subscribe(MapsActivity.this::handleResponse)

       );*/

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        compositeDisposable.clear();
    }
}