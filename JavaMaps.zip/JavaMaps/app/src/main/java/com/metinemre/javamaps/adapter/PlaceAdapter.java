package com.metinemre.javamaps.adapter;

import android.content.Intent;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.metinemre.javamaps.databinding.RecyclerRowBinding;
import com.metinemre.javamaps.model.Place;
import com.metinemre.javamaps.view.MapsActivity;

import java.util.List;

public class PlaceAdapter extends RecyclerView.Adapter<PlaceHolder> {

    List<Place> placeList;


    public PlaceAdapter(List<Place> placeList) {
        this.placeList= placeList;
    }


    @NonNull
    @Override
    public PlaceHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        RecyclerRowBinding recyclerRowBinding = RecyclerRowBinding.inflate(LayoutInflater.from(parent.getContext(),parent,false));
        return new PlaceHolder(recyclerRowBinding);
    }

    @Override
    public int getItemCount() {
        return placeList.size();
    }

    @Override
    public void onBindViewHolder(@NonNull PlaceHolder holder, int position) {
         holder.recyclerRowBinding.recyclerViewTextView.setText(placeList.get(position).name);


         // button click intent !
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Intent intent = new Intent(holder.itemView.getContext(), MapsActivity.class);
                holder.itemView.getContext().startActivity(intent);
            }
        });


    }

    public class PlaceHolder extends RecyclerView.ViewHolder {
        RecyclerRowBinding recyclerRowBinding;




        public PlaceHolder(RecyclerRowBinding recyclerRowBinding) {
            super(recyclerRowBinding.getRoot());
            this.recyclerRowBinding = recyclerRowBinding;
        }
    }
}

