package com.metinemre.javamaps.roomdb;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.metinemre.javamaps.model.Place;

@Database(entities = {Place.class}, version = 1)

public abstract class PlaceDatabase extends RoomDatabase {
    public abstract PlaceDAO placeDAO();



}
